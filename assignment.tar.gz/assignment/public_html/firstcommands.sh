date
hostname
uname -a
echo ~
who
getent passwd | cut -d: -f1

