d=$(ls *.txt );

for i in $d;

do mv $i x$i;

done
echo $d

