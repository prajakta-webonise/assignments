d=$(ls x* );

for i in $d;

do mv $i r$i;

done
echo $d

